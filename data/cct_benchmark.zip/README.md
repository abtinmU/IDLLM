# Counterfactual Compliance Transfer (CCT)

**Version:** 1.0, prompt-only release  
**Task:** pre-generation instruction-compliance prediction under controlled changes in linguistic formulation and required behavior  
**Status:** counterfactual prompts and lineage verified; new model responses and probe scores **not generated**

## Overview

CCT is a paired evaluation suite for studying what a language model's pre-generation representation predicts about future instruction-following. It creates a controlled **2 × 2 design** from previously evaluated tasks and their verifiable output constraints:

| Condition | Required behavior | Formulation | Source |
|---|---|---|---|
| `O` | Original | Canonical | Existing experiment |
| `R1` | Original | Equivalent rewrite | Existing experiment |
| `C0` | Counterfactual | Canonical | This release |
| `C1` | Counterfactual | Equivalent rewrite | This release |

The *wording intervention* contrasts `O` with `R1`, or `C0` with `C1`, holding the requirement value fixed. The *requirement intervention* contrasts `O` with `C0`, or `R1` with `C1`, holding the formulation template fixed. These are controlled **prompt-level interventions**. Evaluating their effects on model behavior requires generating and verifying responses under all conditions. They are not, by themselves, causal interventions on internal neural representations.

CCT reuses source tasks from **IFEval-Simple** (Heo et al., ICLR 2025) and a **controlled task extension of Original IFEval**, rather than collecting entirely new base questions. Its new contribution is the factorial counterfactual construction and paired prediction targets; it is not an independent fourth source corpus. The controlled Original IFEval extension appended a requirement to selected original prompts and evaluated compliance with that added requirement. It must not be described as native Original IFEval scoring.

## Dataset composition

| Section | Source-task setting | Added constraint | Task–constraint instances | Newly constructed prompts |
|---|---|---|---:|---:|
| A | IFEval-Simple | Required ending phrase | 102 | 204 |
| B | IFEval-Simple | Minimum square-bracket placeholders | 102 | 204 |
| C | IFEval-derived controlled extension | Required ending phrase | 161 | 322 |
| D | IFEval-derived controlled extension | Minimum square-bracket placeholders | 169 | 338 |
| **Total** | | | **534** | **1,068** |

A and B share **102 base-task families**; C and D come from **180 distinct base-task families** in the previous controlled IFEval study, and overlap. There are **282 distinct source-task families across both settings**, not 534 independent tasks. Within each constraint instance, C0 and C1 share the same source task and target requirement. Use the supplied task family/group identifiers in resampling and cross-validation.

Each family record includes all four condition prompts, the original/counterfactual checker arguments, task/fold metadata, and hashes. `unified/CCT_counterfactual_prompts.jsonl` holds only the **new C0/C1 inputs**. Prior O/R1 information for sections C/D is additionally included in their parent-prediction files. The earlier IFEval-Simple probe outputs are *not* distributed in this ZIP.

## Counterfactual operators

**Ending phrase:** Replace an exact required terminal phrase with a different exact terminal phrase. The new phrase is evaluated with the end-checker. The two targets are distinct; complying with one does not generally count as complying with the other. Section C replaces `This concludes my response.` with `That completes my explanation.`. Section A preserves each source task's exact canonical ending construction while changing only its ending requirement.

**Placeholder minimum:** Increase the specified minimum number of square-bracket placeholders by **two**, preserving the rest of the source prompt and its verifier type. For Section D, the threshold is **3 → 5**. For Section B, each original threshold is taken from the published IFEval-Simple instance, including values above six. **Success sets are nested:** a response meeting the new minimum also meets the old minimum. Do not interpret the change as a mutually exclusive class switch or assume it must cause a compliance failure.

The benchmark varies **requirement wording** and **requirement values** separately. This does not guarantee that a generated model will behave identically under meaning-preserving wording changes. Whether it does is a measured outcome, not a preassigned label.

## Intended evaluations

Use the **same fixed model revision and generation policy** to obtain a response for each prompt. Apply the appropriate deterministic instruction verifier to the condition-specific target, then extract the model's pre-generation hidden state. Reuse the original fold-specific frozen probes if testing the previous B0/B2/MT0/MT2 methods. Do **not** tune, train, select probe architectures, or choose favorable examples based on held-out C0/C1 outcomes.

Recommended results, reported identically for both source settings:

1. **Cross-formulation compliance discrimination:** AUROC and Brier score for O/R1/C0/C1, together with positive/negative class counts and truncation rates.
2. **Paired compliance changes:** failure→success, success→failure, stable success, stable failure for each controlled intervention.
3. **Counterfactual prediction:** relation between a probe's *signed within-task score change* and the observed compliance change; flip-direction accuracy is conditional on observed flips and must be reported alongside support counts.
4. **Factorial contrasts:** within-family formulation effects at both requirement values; requirement effects at both wordings; their interaction. State clearly whether the outcome is binary compliance, an estimated compliance probability, or AUROC.
5. **Uncertainty:** resample or randomize whole independent source-task families, not individual prompts. Cluster by source group, keeping both constraint types and all conditions together where they share a family.

The release is designed to evaluate predictive sensitivity to interventions, **not** to establish that a particular activation feature causally controls compliance. Neural causal claims require separate activation interventions and suitable controls.

## Files

- `unified/CCT_counterfactual_prompts.jsonl`: complete list of **1,068 new** C0/C1 prompts with task, section, fold, condition, target kwargs, and provenance hashes.
- `sections/A/`, `sections/B/`: unchanged frozen manifests and verifier audits from the prior IFEval-Simple Section A/B construction.
- `sections/C/`, `sections/D/`: original and counterfactual prompts, source-fold information, manual-review flags, protocol files, and the **existing** O/R1 out-of-fold scores in `section_*_parent_predictions.jsonl`.
- `benchmark_protocol.json`: common design and provenance.
- `VALIDATION_REPORT.json`: completed structural checks and remaining validation limits.
- `SHA256SUMS.json`: SHA-256 digest for every other file in this release.
- `validate_release.py`: offline structural and checksum self-test; run `python validate_release.py` from the extracted release directory.

Each `sections/*/section_*_families.jsonl` record describes a complete O/R1/C0/C1 set. The source datasets and earlier experiment archives are **not** required to read or use the constructed prompts, but they are needed to independently reconstruct the source study's pre-generation probes, its original responses, and all cached states.

## Provenance and reproducibility

The source model was **`microsoft/Phi-3-mini-128k-instruct`**, revision `f3c06aed622e14ca0abf5115094e4fc9a9948f36`. Historical generation budgets differ by source setting: **1,024** for IFEval-Simple and **1,536** for the IFEval-derived extension. Follow the per-record budget and input-length metadata when reproducing comparisons to those runs.

The Original IFEval-derived C/D records were reconstructed directly from the completed experimental archive's original/R1 prompts and five-fold out-of-fold predictions. The source record hashes and verifier file hashes are recorded in the section protocols. Sections A/B were preserved byte-for-byte from their previously frozen ZIPs. All Section D records have been checked for exact reversible counterfactual substitution and identity/fold consistency with their parent O/R1 records; the same verification was performed on the reconstructed Section C records.

**Validation status:** SHA-256, pair completeness, uniqueness, source-family matching, original fold consistency, and reversible prompt edits have been checked. The official external verifier was **not executed anew for C/D** in this packaging environment. A/B include the checker-audit reports produced in their prior Colab runs. Source-task semantic compatibility is not automatically guaranteed; consult the flagged cases in the C/D review CSVs, and conduct a manual semantic audit before treating the release as publication-ready. No new C0/C1 responses or empirical effect estimates are included.

## Known limitations and interpretation

- The original IFEval-derived tasks may contain unrelated requirements (e.g., exact formatting) that interact with the added counterfactual. Section C and D review files flag **12** and **36** potentially conflicting cases respectively for inspection. These are conservative heuristic flags, not proof that all other prompts are compatible.
- Higher placeholder minima can sharply change failure prevalence. Verify positive/negative class support on a **development** set before expensive held-out generation; do not filter the test set for favorable results.
- Editing a fixed suffix or threshold changes the required behavior, but may also change lexical length or model difficulty. Interpretation must account for those differences.
- CCT provides controlled *prompt* manipulations; it is not an independent randomized study of internal model mechanisms.
- These are newly constructed prompt records, **not yet a benchmark with completed counterfactual response annotations**. A response-generation and scoring release would be a subsequent version.

## Attribution

Derived source tasks: **IFEval-Simple**, associated with Heo et al., *Do LLMs “Know” Internally When They Follow Instructions?* (ICLR 2025), and **Original IFEval**, Zhou et al., *Instruction-Following Evaluation for Large Language Models* (2023). Follow the upstream repositories' licenses and dataset-use conditions when redistributing source prompt text.
