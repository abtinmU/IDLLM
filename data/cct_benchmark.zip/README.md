# CCT benchmark

This archive contains the 2 x 2 Counterfactual Compliance Transfer prompts used by the experiment.

- Sections A and C test exact response endings.
- Sections B and D test square-bracket placeholder counts.
- O and R1 use the original rule. C0 and C1 use the changed rule.
- `cct_fold` is the frozen five-fold split used for the paper results.
- `unified/CCT_counterfactual_prompts.jsonl` contains the 1,068 new C0/C1 prompts.
- The section family files contain all 2,136 O/R1/C0/C1 prompts.

Run `python validate_release.py cct_benchmark.zip` to check hashes, counts, prompts, and folds.
