"""CCT v1.0: self-contained structural, fold, and integrity checks."""
import json, hashlib, zipfile, collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return [json.loads(x) for x in p.read_text(encoding='utf8').splitlines() if x.strip()]
sha=json.loads((ROOT/'SHA256SUMS.json').read_text())
for name,expected in sha.items():
 p=ROOT/name
 assert p.is_file() and digest(p)==expected,(name,'checksum mismatch')
sections={}
for section,expected in {'A':102,'B':102,'C':161,'D':169}.items():
 d=ROOT/'sections'/section
 fs=load(d/f'section_{section}_families.jsonl');rs=load(d/f'section_{section}_C0_C1_prompts.jsonl')
 assert len(fs)==expected and len(rs)==2*expected
 assert len({r['id'] for r in rs})==2*expected
 assert len({r['prompt_sha256'] for r in rs})==2*expected
 assert all(hashlib.sha256(r['prompt'].encode('utf8')).hexdigest()==r['prompt_sha256'] for r in rs)
 by=collections.defaultdict(list)
 for r in rs:by[r['task_family_id']].append(r)
 assert len(by)==expected
 for f in fs:
  fid=f['task_family_id'];pair=by[fid]
  assert len(pair)==2 and {r['condition'] for r in pair}=={'C0','C1'}
  assert len({r['fold'] for r in pair})==1
  assert len({json.dumps(r['target_kwargs'],sort_keys=True) for r in pair})==1
  for r in pair:
   assert r['prompt']==f[r['condition']+'_prompt']
 sections[section]=fs
A={f['task_id']:f for f in sections['A']};B={f['task_id']:f for f in sections['B']}
assert set(A)==set(B)==set(range(102))
for k in A:assert A[k]['base_task']==B[k]['base_task'] and A[k]['fold']==B[k]['fold']
C={f['task_id']:f for f in sections['C']};D={f['task_id']:f for f in sections['D']}
assert len(set(C)|set(D))==180
for k in set(C)&set(D):
 assert (C[k]['base_task'],C[k]['fold'],C[k]['group'])==(D[k]['base_task'],D[k]['fold'],D[k]['source_group'])
all_new=load(ROOT/'unified/CCT_counterfactual_prompts.jsonl')
assert len(all_new)==1068 and len({r['id'] for r in all_new})==1068
assert all(hashlib.sha256(r['prompt'].encode()).hexdigest()==r['prompt_sha256'] for r in all_new)
assert collections.Counter(r['section'] for r in all_new)=={'A':204,'B':204,'C':322,'D':338}
assert {r['section'] for r in all_new}==set(sections)
print('PASS: all SHA-256 digests, 1,068 prompts, pair completeness, 282 unique source families, source linkage and folds')
