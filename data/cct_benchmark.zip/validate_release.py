import hashlib, json, sys, zipfile

p=sys.argv[1] if len(sys.argv)>1 else "cct_benchmark.zip"
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 sums=json.loads(z.read("SHA256SUMS.json"))
 assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in sums.items())
 rows=[json.loads(x) for x in z.read("unified/CCT_counterfactual_prompts.jsonl").decode().splitlines() if x]
 assert len(rows)==1068 and len({r["id"] for r in rows})==1068
 assert len({r["task_family_id"] for r in rows})==282
 assert set(r["fold"] for r in rows)==set(range(5))
 assert all(hashlib.sha256(r["prompt"].encode()).hexdigest()==r["prompt_sha256"] for r in rows)
print("CCT release validation: PASS")
